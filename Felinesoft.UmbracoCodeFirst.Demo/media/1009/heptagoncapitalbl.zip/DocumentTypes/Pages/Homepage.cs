﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using HeptagonCapital.BL.DocumentTypes.Tabs;
using System;

namespace HeptagonCapital.BL.DocumentTypes.Pages
{
    [DocumentType(icon: BuiltInIcons.IconHome, allowedChildren: new Type[]
    { 
        typeof(Settings),
        typeof(GenericContentPage),
        typeof(ContentListing),
        typeof(Disclaimer)
    })]
    [Template(isDefault: true)]
    public class Homepage : Webpage
    {
        [ContentTab]
        public Card Card1 { get; set; }

        [ContentTab]
        public Card Card2 { get; set; }

        [ContentTab]
        public Card Card3 { get; set; }
    }
}
