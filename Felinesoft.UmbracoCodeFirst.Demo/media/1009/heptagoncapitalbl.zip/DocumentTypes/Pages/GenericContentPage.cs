﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using HeptagonCapital.BL.DocumentTypes.Tabs;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using System;

namespace HeptagonCapital.BL.DocumentTypes.Pages
{
    [DocumentType(icon: BuiltInIcons.IconUmbContent, allowedChildren: new Type[] { typeof(GenericContentPage) })]
    [Template(isDefault: true)]
    public class GenericContentPage : Webpage
    {
        [ContentTab]
        public GenericContent Content { get; set; }

        [ContentTab]
        public ListInfo ListInfo { get; set; }
    }
}
