﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.DocumentTypes.Pages
{
    [DocumentType(icon: BuiltInIcons.IconBulletedList, allowedChildren: new Type[] { typeof(GenericContentPage) })]
    public class ContentListing : Webpage
    {
    }
}
