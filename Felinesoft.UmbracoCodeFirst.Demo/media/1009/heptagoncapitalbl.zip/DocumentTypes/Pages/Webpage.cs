﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using HeptagonCapital.BL.DocumentTypes.Tabs;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Umbraco.Web;

namespace HeptagonCapital.BL.DocumentTypes.Pages
{
    [DocumentType]
    [Template(isDefault: true)]
    public class Webpage : Base
    {
        [ContentTab(sortOrder: 11)]
        public Hero Hero { get; set; }

        [ContentTab(sortOrder: 12)]
        public SEO SEO { get; set; }

        [ContentProperty]
        public TrueFalse ShowDisclaimer { get; set; }

        [ContentProperty]
        public DatePicker DateOverride { get; set; }

        [ContentProperty(alias: "umbracoNaviHide", addTabAliasToPropertyAlias: false)]
        public TrueFalse HideFromNavigation { get; set; }
    }
}
