﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HeptagonCapital.BL.MediaTypes;

namespace HeptagonCapital.BL.DocumentTypes.Tabs
{
    public class Hero : TabBase
    {
        [ContentProperty]
        public TrueFalse ShowHero { get; set; }

        [ContentProperty]
        public Textstring Header { get; set; }

        [ContentProperty]
        public TextboxMultiple Subheader { get; set; }

        [ContentProperty]
        public SingleMediaPicker<MediaImage> Image { get; set; }        
    }
}
