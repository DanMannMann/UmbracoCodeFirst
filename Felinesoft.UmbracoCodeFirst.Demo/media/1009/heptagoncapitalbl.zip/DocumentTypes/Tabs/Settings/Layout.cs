﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using HeptagonCapital.BL.MediaTypes;

namespace HeptagonCapital.BL.DocumentTypes.Tabs.Settings
{
    public class Layout : TabBase
    {
        [ContentProperty]
        public SingleMediaPicker<MediaImage> HeaderLogo { get; set; }

        [ContentProperty]
        public RichtextEditor Footer { get; set; }
    }
}
