﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.DocumentTypes.Tabs
{
    public class SEO : TabBase
    {
        [ContentProperty((alias: "seoSitemapRoot"))]
        public TrueFalse SitemapRoot { get; set; }

        [ContentProperty((alias: "seoNoIndex"))]
        public TrueFalse NoIndex { get; set; }

        [ContentProperty((alias: "metaTitle"))]
        public Textstring MetaTitle { get; set; }

        [ContentProperty((alias: "metaDescription"))]
        public TextboxMultiple MetaDescription { get; set; }

        // NOTE: This will need replacing if we ever define an author node type
        [ContentProperty((alias: "seoAuthor"))]
        public SingleDocumentPicker<Base> Author { get; set; }

        [ContentProperty((alias: "seoPriority"))]
        public Numeric Priority { get; set; }

        [ContentProperty((alias: "seoChangeFrequency"))]
        public Numeric ChangeFrequency { get; set; }
    }
}
