﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using HeptagonCapital.BL.DocumentTypes.Pages;

namespace HeptagonCapital.BL.DocumentTypes.Tabs
{
    public class Card : TabBase
    {
        [ContentProperty]
        public Textstring Title { get; set; }

        [ContentProperty]
        public TextboxMultiple Body { get; set; }

        [ContentProperty]
        public SingleDocumentPicker<Webpage> LearnMore { get; set; }
    }
}
