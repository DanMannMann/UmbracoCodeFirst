﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.DocumentTypes.Tabs
{
    public class Disclaimer : TabBase
    {
        [ContentProperty]
        public Textstring Header { get; set; }

        [ContentProperty]
        public Textstring Tab1Header { get; set; }

        [ContentProperty]
        public RichtextEditor Tab1Content { get; set; }

        [ContentProperty]
        public Textstring Tab2Header { get; set; }

        [ContentProperty]
        public RichtextEditor Tab2Content { get; set; }

        [ContentProperty]
        public Textstring AgreeButtonText { get; set; }

        [ContentProperty]
        public Textstring DisagreeButtonText { get; set; }
    }
}
