﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using Felinesoft.UmbracoCodeFirst.ContentTypes;

namespace HeptagonCapital.BL.DocumentTypes.Tabs
{
    public class Content : TabBase
    {
        [ContentProperty]
        public Textstring Header { get; set; }

        [ContentProperty]
        public Textstring SubHeader { get; set; }       
    }
}
