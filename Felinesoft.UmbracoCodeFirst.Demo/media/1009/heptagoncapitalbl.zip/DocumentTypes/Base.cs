﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using HeptagonCapital.BL.DocumentTypes.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Umbraco.Web;
using Felinesoft.UmbracoCodeFirst.Extensions;

namespace HeptagonCapital.BL.DocumentTypes
{
    [DocumentType]
    public class Base : DocumentTypeBase
    {
        public Homepage GetHomepage ()
        {
            try
            {
                return this.NodeDetails.PublishedContent.AncestorOrSelf(1).ConvertToModel<Homepage>();
            }
            catch (Exception)
            {
                throw new Exception("Could not find the HomePage");
            }
            
        }

        public Settings GetSettings ()
        {
            try
            {
                return GetHomepage().NodeDetails.PublishedContent.Children.FirstOrDefault(x => x.DocumentTypeAlias == new Settings().NodeDetails.ContentTypeAlias).ConvertToModel<Settings>();
            }
            catch (Exception)
            {
                throw new Exception("Could not find Settings");
            }
        }
    }
}
