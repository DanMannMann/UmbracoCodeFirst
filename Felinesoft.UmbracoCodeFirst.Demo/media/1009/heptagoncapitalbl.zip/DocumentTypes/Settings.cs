﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using HeptagonCapital.BL.DocumentTypes.Tabs.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.DocumentTypes
{
    [DocumentType(icon: BuiltInIcons.IconSettings)]
    public class Settings : Base
    {      
        [ContentTab]
        public Layout Layout { get; set; }
    }
}
