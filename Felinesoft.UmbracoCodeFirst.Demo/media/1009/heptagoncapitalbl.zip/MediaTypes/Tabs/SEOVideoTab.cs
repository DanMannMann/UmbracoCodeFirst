﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.MediaTypes.Tabs
{
    public class SEOVideoTab : TabBase
    {
        [ContentProperty(alias: "videoUrl", addTabAliasToPropertyAlias: false)]
        public Textstring VideoUrl { get; set; }

        [ContentProperty(alias: "thumbnail", addTabAliasToPropertyAlias: false)]
        public Upload Thumbnail { get; set; }

        [ContentProperty(alias: "title", addTabAliasToPropertyAlias: false)]
        public Textstring Title { get; set; }

        [ContentProperty(alias: "description", addTabAliasToPropertyAlias: false)]
        public Textstring Description { get; set; }

        [ContentProperty(alias: "duration", addTabAliasToPropertyAlias: false)]
        public Numeric Duration { get; set; }

        [ContentProperty(alias: "expirationDate", addTabAliasToPropertyAlias: false)]
        public DatePicker ExpirationDate { get; set; }

        [ContentProperty(alias: "rating", addTabAliasToPropertyAlias: false)]
        public Numeric Rating { get; set; }

        [ContentProperty(alias: "publicationDate", addTabAliasToPropertyAlias: false)]
        public DatePicker PublicationDate { get; set; }

        [ContentProperty(alias: "notFamilyFriendly", addTabAliasToPropertyAlias: false)]
        public TrueFalse NotFamilyFriendly { get; set; }

        [ContentProperty(alias: "category", addTabAliasToPropertyAlias: false)]
        public Textstring Catagory { get; set; }

        [ContentProperty(alias: "galleryLocation", addTabAliasToPropertyAlias: false)]
        public Textstring GalleryLocation { get; set; }

        [ContentProperty(alias: "uploader", addTabAliasToPropertyAlias: false)]
        public Textstring Uploader { get; set; }

        [ContentProperty(alias: "uploaderInfoUrl", addTabAliasToPropertyAlias: false)]
        public Textstring UploaderInfoUrl { get; set; }

        [ContentProperty(alias: "tags", addTabAliasToPropertyAlias: false)]
        public Tags Tags { get; set; }
    }
}
