﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using Felinesoft.UmbracoCodeFirst.DataTypes.BuiltIn;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.MediaTypes.Tabs
{
    public class SEOImageTab : TabBase
    {
        [ContentProperty(alias: "caption", addTabAliasToPropertyAlias: false)]
        public Textstring Caption { get; set; }

        [ContentProperty(alias: "geolocation", addTabAliasToPropertyAlias: false)]
        public Textstring GeographicLocation { get; set; }

        [ContentProperty(alias: "license", addTabAliasToPropertyAlias: false)]
        public Textstring License { get; set; }

        [ContentProperty(alias: "title", addTabAliasToPropertyAlias: false)]
        public Textstring Title { get; set; }
    }
}
