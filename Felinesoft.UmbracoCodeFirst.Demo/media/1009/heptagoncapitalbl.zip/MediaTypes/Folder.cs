﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.MediaTypes
{
    [MediaType(icon: BuiltInIcons.Folder)]
    public class Folder : MediaFolderBase
    {
    }
}
