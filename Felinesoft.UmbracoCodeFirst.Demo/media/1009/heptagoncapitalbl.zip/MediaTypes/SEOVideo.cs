﻿using Felinesoft.UmbracoCodeFirst.Attributes;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using HeptagonCapital.BL.MediaTypes.Tabs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeptagonCapital.BL.MediaTypes
{
    [MediaType(icon: BuiltInIcons.IconVideo)]
    public class SEOVideo : MediaImageBase
    {
        [ContentTab]
        public SEOVideoTab SEO { get; set; }
    }
}
