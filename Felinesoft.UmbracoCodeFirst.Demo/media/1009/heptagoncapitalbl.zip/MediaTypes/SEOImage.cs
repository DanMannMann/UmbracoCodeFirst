﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Felinesoft.UmbracoCodeFirst.ContentTypes;
using Felinesoft.UmbracoCodeFirst.Attributes;
using HeptagonCapital.BL.MediaTypes.Tabs;
namespace HeptagonCapital.BL.MediaTypes
{
    [MediaType(icon: BuiltInIcons.IconUmbMedia)]
    public class SEOImage : MediaImageBase
    {
        [ContentTab]
        public SEOImageTab SEO { get; set; }
    }
}
